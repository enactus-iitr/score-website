export const colors = {
  yellow: '#FEC223',
  yellowBar: '#FEC223CC',
  blue: '#191C4D',
  brown: '#33201C',
  grey: '#E2E2E2',
  white: '#FFFFFF',
  lightblue: '#313576',
  lightPurple: '#2D3170'
}
