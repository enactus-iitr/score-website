let data = [
  {
    class: '11',
    physics: {
      desc:
        'Phsics, Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores voluptatum exercitationem vel? Aspernatur eveniet ut repellat, perspiciatis inventore, consequuntur, quis ea nemo commodi tenetur voluptates.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores voluptatum exercitationem vel? Aspernatur eveniet ut repellat, perspiciatis inventore, consequuntur, quis ea nemo commodi tenetur voluptates.'
    },
    chemistry: {
      desc:
        'chemistry, Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores voluptatum exercitationem vel? Aspernatur eveniet ut repellat, perspiciatis inventore, consequuntur, quis ea nemo commodi tenetur voluptates.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores voluptatum exercitationem vel? Aspernatur eveniet ut repellat, perspiciatis inventore, consequuntur, quis ea nemo commodi tenetur voluptates.'
    },
    maths: {
      desc:
        'maths, Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores voluptatum exercitationem vel? Aspernatur eveniet ut repellat, perspiciatis inventore, consequuntur, quis ea nemo commodi tenetur voluptates.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores voluptatum exercitationem vel? Aspernatur eveniet ut repellat, perspiciatis inventore, consequuntur, quis ea nemo commodi tenetur voluptates.'
    }
  },
  {
    class: '12',
    physics: {
      desc:
        'Phsics, Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores voluptatum exercitationem vel? Aspernatur eveniet ut repellat, perspiciatis inventore, consequuntur, quis ea nemo commodi tenetur voluptates.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores voluptatum exercitationem vel? Aspernatur eveniet ut repellat, perspiciatis inventore, consequuntur, quis ea nemo commodi tenetur voluptates.'
    },
    chemistry: {
      desc:
        'chemistry, Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores voluptatum exercitationem vel? Aspernatur eveniet ut repellat, perspiciatis inventore, consequuntur, quis ea nemo commodi tenetur voluptates.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores voluptatum exercitationem vel? Aspernatur eveniet ut repellat, perspiciatis inventore, consequuntur, quis ea nemo commodi tenetur voluptates.'
    },
    maths: {
      desc:
        'maths, Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores voluptatum exercitationem vel? Aspernatur eveniet ut repellat, perspiciatis inventore, consequuntur, quis ea nemo commodi tenetur voluptates.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores voluptatum exercitationem vel? Aspernatur eveniet ut repellat, perspiciatis inventore, consequuntur, quis ea nemo commodi tenetur voluptates.'
    }
  }
]

export default data
