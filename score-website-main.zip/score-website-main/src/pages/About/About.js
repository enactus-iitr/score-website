import React from 'react'
import BasicLayout from '../../layouts/BasicLayout.js'
import useStyles from './styles.js'

export default function About () {
  const classes = useStyles()

  return <BasicLayout>ABOUT PAGE</BasicLayout>
}
